exports.handler = (event) => {
    console.log('This is a lambda created using terraform', event)
}